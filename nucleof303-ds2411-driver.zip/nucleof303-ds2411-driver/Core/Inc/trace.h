/*
 * trace.h
 *
 *  Created on: Jun 17, 2020
 *      Author: Muhammad Abu Bakar
 */

#ifndef TRACE_H_
#define TRACE_H_

#include "stm32f3xx_hal.h"
/******************************************************************************/
/*----------------------------------Includes----------------------------------*/
/******************************************************************************/


extern UART_HandleTypeDef huart2;
/******************************************************************************/
/*-----------------------------------Macros-----------------------------------*/
/******************************************************************************/

#define DEBUG_TRACE			1
#define DEBUG_LOG			1

/******************************************************************************/
/*-------------------------Function Prototypes--------------------------------*/
/******************************************************************************/

extern void trace(char *, ...);
extern void logs(char *);
extern void InitUart(void);

#if DEBUG_TRACE
#define TRACE trace
#else
#define TRACE {}
#endif

#if DEBUG_LOG
#define LOG logs
#else
#define LOG {}
#endif

extern void clrscr(void);

#endif /* TRACE_H_ */
