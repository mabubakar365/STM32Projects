/*
 * delay.h
 *
 *  Created on: Oct 4, 2023
 *      Author: abu.bakar
 */

#ifndef INC_DELAY_H_
#define INC_DELAY_H_

extern void delayMicroseconds(unsigned int us);
extern void delayMilliseconds(unsigned int ms);

#endif /* INC_DELAY_H_ */
