/*
 * DS2411.h
 *
 *  Created on: Oct 5, 2023
 *      Author: abu.bakar
 */

#ifndef INC_DS2411_H_
#define INC_DS2411_H_

#include<stdint.h>

void DS2411_Init();
void DS2411_GetID(uint8_t *DataNum);   //get 8byte DS2411 number
void DS2411_GetMAC(uint8_t *DataMAC);   //get 6byte Mac
void DS2411_GetCharAll_P(char *charNumber);   // char 16 byte
char* DS2411_GetCharAll_NP();
void DS2411_GetChar_P(char *charNumber);    // char  12 byte
char* DS2411_GetChar_NP();
void DS2411_App();

#endif /* INC_DS2411_H_ */
