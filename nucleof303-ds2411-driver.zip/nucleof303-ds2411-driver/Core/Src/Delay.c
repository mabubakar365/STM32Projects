#include "Delay.h"
#include "main.h"

extern TIM_HandleTypeDef htim1;

extern void delayMicroseconds(unsigned int us)
{
	__HAL_TIM_SET_COUNTER(&htim1, 0);
	while(__HAL_TIM_GET_COUNTER(&htim1) <= us);
}

extern void delayMilliseconds(unsigned int ms)
{
	HAL_Delay(ms);
}
