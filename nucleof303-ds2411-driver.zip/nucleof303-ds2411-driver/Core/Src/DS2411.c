/*
 * DS2411.c
 *
 *  Created on: Oct 5, 2023
 *      Author: abu.bakar
 */
#include "DS2411.h"
#include "Owire.h"
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "trace.h"

#define bitSet(value, bit) ((value) |= (1UL << (bit)))
#define bitClear(value, bit) ((value) &= ~(1UL << (bit)))
#define bitWrite(value, bit, bitvalue) (bitvalue ? bitSet(value, bit) : bitClear(value, bit))

uint8_t _IOpin;
uint8_t DataID[8];
uint8_t DataIDR[8];
char tempStrNumber[20];

OWire ds2411;

void DS2411_Init()
{
	OWInit(&ds2411, GPIOA, GPIO_PIN_5);
	bool present;
	present = OWReset(&ds2411);
	if (present == TRUE)
	{
		OWWrite(&ds2411, 0x33); // Read data command, leave ghost power off
		for (uint8_t i = 0; i < 8; i++)
		{
			DataID[i] = OWRead(&ds2411);
			 //= *(IDdata+i);
			DataIDR[7-i] = DataID[i];
		}
	}
}

void DS2411_GetID(uint8_t *DataNum)
{
	for ( uint8_t i = 0; i < 8; i++)
		{
			*(DataNum+i) = DataID[i];
		}
}

void DS2411_GetMAC(uint8_t *DataMAC)
{
	for ( uint8_t i = 0; i < 6; i++)
	{
		*(DataMAC + i) = DataIDR[i+1];
	}
	if(0) // replace with condition to write 1
	{
		bitSet(DataMAC[0], 0);
	}
	else
	{
		bitClear(DataMAC[0], 0);
	}
}

void DS2411_GetCharAll_P(char *StrNumber)
{
	char str[3];
	tempStrNumber[0] = '\0';
	for (uint8_t a = 0; a < 8; a++)
	{
		if(DataIDR[a] <= 0x0F)
		{
			sprintf(str, "%02X", DataIDR[a]);
			strcat(tempStrNumber, "0");
			strcat(tempStrNumber, str);
		}
		else
		{
			sprintf(str, "%02X", DataIDR[a]);
			strcat(tempStrNumber, str);
		}

	}
	uint8_t macStrLine =  strlen(tempStrNumber);
	memcpy(StrNumber, tempStrNumber, macStrLine + 1);
	tempStrNumber[0] = '\0';
}

char* DS2411_GetCharAll_NP()
{
    tempStrNumber[0] = '\0'; // Initialize to an empty string

    for (uint8_t a = 0; a < 8; a++)
    {
        char str[3];
        if(DataIDR[a] <= 0x0F)
        {
            sprintf(str, "%02X", DataIDR[a]); // Convert the byte to a hexadecimal string
            strcat(tempStrNumber, "0");
            strcat(tempStrNumber, str);
        }
        else
        {
            sprintf(str, "%02X", DataIDR[a]); // Convert the byte to a hexadecimal string
            strcat(tempStrNumber, str);
        }
    }
    return tempStrNumber;
}

void DS2411_GetChar_P(char *StrNumber)
{
	tempStrNumber[0] = '\0'; // Initialize to an empty string
	for (uint8_t a = 1; a < 7; a++)
	{
		char str[3];
		if(DataIDR[a] <= 0x0F)
		{
            sprintf(str, "%02X", DataIDR[a]); // Convert the byte to a hexadecimal string
            strcat(tempStrNumber, "0");
            strcat(tempStrNumber, str);
		}
		else
		{
            sprintf(str, "%02X", DataIDR[a]); // Convert the byte to a hexadecimal string
            strcat(tempStrNumber, str);
		}
	}

	uint8_t macStrLine =  strlen(tempStrNumber);
	memcpy(StrNumber, tempStrNumber, macStrLine + 1);
	tempStrNumber[0] = '\0';
}

char* DS2411_GetChar_NP()
{
	tempStrNumber[0] = '\0';
	for (uint8_t a = 1; a < 7; a++)
	{
		char str[3];
		if(DataIDR[a] <= 0x0F)
		{
            sprintf(str, "%02X", DataIDR[a]); // Convert the byte to a hexadecimal string
            strcat(tempStrNumber, "0");
            strcat(tempStrNumber, str);
		}
		else
		{
            sprintf(str, "%02X", DataIDR[a]); // Convert the byte to a hexadecimal string
            strcat(tempStrNumber, str);
		}
	}
	return tempStrNumber;
}

void DS2411_App()
{
	uint8_t data[8];
	DS2411_Init();
	DS2411_GetID(data);   //get data

	TRACE("DS2411 device data\r\n");
	for(uint8_t a = 0; a < 8; a++)  //print data
	{
		TRACE("%02x\r\n", data[a]);
	}
	TRACE("\r\n");
}
